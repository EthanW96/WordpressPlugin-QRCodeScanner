(function() {
    'use strict';

    const { createElement, render, useState, useEffect } = wp.element;
    const { registerBlockType } = wp.blocks;
    const { BlockEditorProvider, BlockList, WritingFlow, ObserveTyping, BlockInserter, BlockToolbar } = wp.blockEditor;
    const { Popover, SlotFillProvider, ToolbarGroup, ToolbarButton } = wp.components;
    const { useSelect, useDispatch } = wp.data;

    // Initialize the block editor when DOM is ready
    document.addEventListener('DOMContentLoaded', function() {
        const editorContainer = document.getElementById('qr-message-2-editor-container');
        const textarea = document.getElementById('qr_message_2');
        
        if (!editorContainer || !textarea) {
            return;
        }

        // Get initial content from textarea
        const initialContent = textarea.value || '';

        // Ensure Stackable blocks are available
        if (typeof wp !== 'undefined' && wp.blocks) {
            // Register Stackable blocks if they exist
            const stackableBlocks = [
                'stackable/hero',
                'stackable/heading',
                'stackable/text',
                'stackable/button',
                'stackable/columns',
                'stackable/column',
                'stackable/container',
                'stackable/divider',
                'stackable/spacer',
                'stackable/image',
                'stackable/icon',
                'stackable/icon-list',
                'stackable/accordion',
                'stackable/tabs',
                'stackable/testimonial',
                'stackable/team-member',
                'stackable/pricing-box',
                'stackable/feature',
                'stackable/feature-grid',
                'stackable/card',
                'stackable/notification',
                'stackable/cta',
                'stackable/cta-text',
                'stackable/cta-image',
                'stackable/cta-video',
                'stackable/cta-2-col',
                'stackable/cta-3-col',
                'stackable/cta-4-col',
                'stackable/cta-5-col',
                'stackable/cta-6-col',
                'stackable/cta-7-col',
                'stackable/cta-8-col',
                'stackable/cta-9-col',
                'stackable/cta-10-col',
                'stackable/cta-11-col',
                'stackable/cta-12-col'
            ];

            // Check if Stackable blocks are available and register them
            stackableBlocks.forEach(blockName => {
                if (wp.blocks.getBlockType(blockName)) {
                    // Block is already registered, make sure it's available
                    console.log('Stackable block available:', blockName);
                }
            });
        }

        // Create the block editor component
        const BlockEditorComponent = () => {
            const [blocks, setBlocks] = useState([]);
            const [isInitialized, setIsInitialized] = useState(false);

            // Initialize blocks from content
            useEffect(() => {
                if (!isInitialized && initialContent) {
                    try {
                        // Try to parse as block content
                        const parsedBlocks = wp.blocks.parse(initialContent);
                        setBlocks(parsedBlocks);
                    } catch (e) {
                        // If parsing fails, create a paragraph block with the content
                        setBlocks([{
                            clientId: 'initial-block',
                            name: 'core/paragraph',
                            attributes: {
                                content: initialContent
                            }
                        }]);
                    }
                    setIsInitialized(true);
                }
            }, [isInitialized, initialContent]);

            // Update textarea when blocks change
            useEffect(() => {
                if (isInitialized) {
                    const serializedContent = wp.blocks.serialize(blocks);
                    textarea.value = serializedContent;
                    
                    // Trigger change event for form validation
                    const event = new Event('change', { bubbles: true });
                    textarea.dispatchEvent(event);
                }
            }, [blocks, isInitialized]);

            const onBlocksChange = (newBlocks) => {
                setBlocks(newBlocks);
            };

            if (!isInitialized) {
                return createElement('div', { 
                    style: { padding: '20px', textAlign: 'center' } 
                }, 'Loading block editor...');
            }

            return createElement(SlotFillProvider, {}, [
                createElement(BlockEditorProvider, {
                    value: blocks,
                    onInput: onBlocksChange,
                    onChange: onBlocksChange,
                    settings: {
                        hasFixedToolbar: true,
                        focusMode: false,
                        hasReducedUI: false,
                        __experimentalFeatures: {
                            typography: {
                                dropCap: false
                            }
                        }
                    }
                }, [
                    createElement('div', {
                        key: 'block-editor',
                        className: 'qr-block-editor',
                        style: {
                            border: '1px solid #ddd',
                            borderRadius: '4px',
                            minHeight: '200px',
                            position: 'relative'
                        }
                    }, [
                        createElement('div', {
                            key: 'toolbar',
                            style: {
                                borderBottom: '1px solid #ddd',
                                padding: '10px',
                                background: '#f8f9fa',
                                borderRadius: '4px 4px 0 0'
                            }
                        }, [
                            createElement(BlockInserter, {
                                key: 'inserter',
                                rootClientId: null,
                                clientId: null
                            })
                        ]),
                        createElement('div', {
                            key: 'content',
                            style: {
                                padding: '10px',
                                minHeight: '150px'
                            }
                        }, [
                            createElement(BlockList, {
                                key: 'block-list'
                            })
                        ])
                    ])
                ])
            ]);
        };

        // Render the block editor
        const blockEditorElement = createElement(BlockEditorComponent);
        render(blockEditorElement, editorContainer);
    });

})();
